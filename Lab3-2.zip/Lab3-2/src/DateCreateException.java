
public class DateCreateException extends Exception{
    public DateCreateException(){
        System.out.println("date wrong!");
    }
}
